<html><table>
<tr><td colspan="2" align="center"><img width="0" height="0"><br/>⌈ Minecraft 1.21.11 ⌋<br/><img width="0" height="0"></td></tr>
<tr><td colspan="2" align="center"><img width="0" height="0"><br/>
:warning: This repository is not official, approved, endorsed, associated or connected with Mojang :warning:
<br/><img width="0" height="0"></td></tr>
</table></html>